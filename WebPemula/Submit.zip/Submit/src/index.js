/*
        jangan ubah kode di bawah ini ya!
*/

import "regenerator-runtime";
import '@fortawesome/fontawesome-free/js/fontawesome'
import '@fortawesome/fontawesome-free/js/solid'
import '@fortawesome/fontawesome-free/js/regular'
import '@fortawesome/fontawesome-free/js/brands'
import "./styles/main.css";
import "./scripts/component/banner-bar.js";  /*  Custom Element */
import "./scripts/component/footer-bar.js";  /*  Custom Element */
import "./scripts/component/side-bar.js";  /*  Custom Element */
import main from "./scripts/main";

main();